# Copyright © 2018 Clarity Movement Co. All rights reserved.
from .patch import patch

__all__ = ['patch']
