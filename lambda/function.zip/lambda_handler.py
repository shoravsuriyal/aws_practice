import boto3

dynamodb= boto3.client('dynamodb')


def lambda_handler(event,cotext):
    
    response = dynamodb.delete_table(TableName='SampleTable')

    table_name = "SampleTable"
    table = dynamodb.create_table(
    TableName=table_name,
    KeySchema=[{"AttributeName": "Name", "KeyType": "HASH"}],
    
    AttributeDefinitions=[{"AttributeName": "Name", "AttributeType": "S"}],
     
    ProvisionedThroughput={
        'ReadCapacityUnits': 10,
        'WriteCapacityUnits': 10
    })

    dynamodb.put_item(TableName='SampleTable', Item={"Name": {"S": "John"}})
    dynamodb.put_item(TableName='SampleTable', Item={"Name": {"S": "Bob"}}) 
    dynamodb.put_item(TableName='SampleTable', Item={"Name": {"S": "Taylor"}})
    
    #dynamodb.put_item(TableName='SampleTable',Key={'Name':{'S':'John'}})

    print 'I am executed successfully'
    return response



